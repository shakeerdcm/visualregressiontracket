export const formatDateTime = (date: string) => new Date(date).toLocaleString();
