export interface BuildDto {
  ciBuildId?: string;
  isRunning?: boolean;
}
