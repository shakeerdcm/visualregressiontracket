export enum TestStatus {
  new = "new",
  unresolved = "unresolved",
  failed = "failed",
  approved = "approved",
  autoApproved = "autoApproved",
  ok = "ok",
}
