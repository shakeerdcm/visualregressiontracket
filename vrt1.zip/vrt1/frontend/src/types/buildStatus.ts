export enum BuildStatus {
  passed = "passed",
  unresolved = "unresolved",
  failed = "failed",
}
