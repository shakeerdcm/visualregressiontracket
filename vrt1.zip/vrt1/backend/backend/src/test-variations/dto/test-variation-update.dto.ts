export class TestVariationUpdateDto {
  baselineName?: string;
  ignoreAreas?: string;
  comment?: string;
}
