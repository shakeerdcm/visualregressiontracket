export interface ModifyBuildDto {
    ciBuildId?: string;
    isRunning?: boolean;
}
