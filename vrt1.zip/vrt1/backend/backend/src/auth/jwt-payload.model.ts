export interface JwtPayload {
  email: string;
  expire?: Date;
}
